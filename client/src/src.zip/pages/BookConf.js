// import Navbar from "../components/Navbar";
// import bgi from "../assets/bg.png";
// import ld from "../assets/ld.png";

// export default function BookConf() {
//   return (
//     <header className=" w-screen h-screen relative bg-slate overflow-hidden">
//       <Navbar />
//       <img
//         src={ld}
//         className="absolute top-16 left-0 w-1/2 h-full object-cover overflow-hidden"
//       />
//       <img
//         src={bgi}
//         className="absolute top-0 left-0 w-full h-full object-cover overflow-hidden"
//       />
//       <div className="absolute top-1/3 left-1/2 space-y-3 flex flex-col mr-10">
//         <h1 class="  text-4xl font-bold text-black flex">
//           Great! xxxxx, everything is ready.
//         </h1>
//         <h2 class="   text-2xl text-black flex">
//           You will receive a confirmation email soon with your booking details.
//         </h2>
//         <button class=" bg-grey-700 hover:bg-black text-white  text-xl rounded-full text-center w-64 h-16 py-2 px-4">
//           Go to homepage
//         </button>
//       </div>
//       {/* <img
//         src={rect}
//         className="absolute w-64 h-16 top-96 right-32 -translate-x-1/2 -translate-y-1/2"
//       /> */}
//     </header>
//   );
// }
